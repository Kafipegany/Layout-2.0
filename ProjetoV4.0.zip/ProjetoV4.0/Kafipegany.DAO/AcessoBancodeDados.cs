﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;
using Kafipegany.Entidades;
using System.Data;

namespace Kafipegany.DAL

{
    public class AcessoBancodeDados
    {
        //Criação de variaveis privadas
        private MySqlConnection conn;
        private DataTable data;
        private MySqlDataAdapter da;
        private MySqlDataReader dr;
        private MySqlCommandBuilder cb;

        //Variaveis da string de conexão
        private string server = "localhost";
        private string user = "root";
        private string password = "usbw";
        private string database = "Kafipegany";

        //Metodo para conectar no banco
        public void Conectar()
        {
            if (conn != null)
                conn.Close();

            string connStr = string.Format("server={0};user id={1};password={2}; database={3}; pooling =false", server, user, password, database);


            try
            {
                conn = new MySqlConnection(connStr);
                conn.Open();
            }
            catch (MySqlException ex)
            {

                throw new Exception(ex.Message); 
            }
        }


        //execultar comandos sql
        public void ExecultarComandoSql(string comandoSql)
        {
            MySqlCommand comando = new MySqlCommand(comandoSql, conn);
            comando.ExecuteNonQuery();
            conn.Close();
        }

        //
        public DataTable RetDataTable(string sql)
        {
            data = new DataTable();
            da = new MySqlDataAdapter(sql, conn);
            cb = new MySqlCommandBuilder(da);
            da.Fill(data);

            return data;
        }

        //
        public MySqlDataReader RetDataReader(string sql)
        {
            MySqlCommand comando = new MySqlCommand(sql, conn);
            MySqlDataReader dr = comando.ExecuteReader();
            dr.Read();

            return dr;
        }
    }
}
