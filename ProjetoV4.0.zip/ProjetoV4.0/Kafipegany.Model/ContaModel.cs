﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kafipegany.DAL;
using Kafipegany.Entidades;
using MySql.Data.MySqlClient;

namespace Kafipegany.Model
{
    public class ContaModel
    {
        AcessoBancodeDados bd;

        

    }
}
