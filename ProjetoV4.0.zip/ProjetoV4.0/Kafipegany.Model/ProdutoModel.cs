﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kafipegany.DAL;
using Kafipegany.Entidades;
using MySql.Data.MySqlClient;

namespace Kafipegany.Model
{
    class ProdutoModel
    {
        AcessoBancodeDados bd;

        public void InserirProduto(tb_produto tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Ds_produto.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBancodeDados();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "INSERT INTO tb_produto(ds_produto,vl_produto,qt_produto,qt_minima) VALUES('" + tb.Ds_produto + "','" + tb.Vl_produto + "','" + tb.Qt_produto + "''" + tb.Qt_minima + "')";
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o Produto: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void AtualizarProduto(tb_produto tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Ds_produto.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBancodeDados();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "UPDATE tb_produto set ds_produto = '" + tb.Ds_produto + "',vl_produto='" + tb.Vl_produto + "', qt_produto='" + tb.Qt_produto + "' qt_minima='" + tb.Qt_minima + "' where cd_produto =" + tb.Cd_produto;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o Produto: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }
        public DataTable SelecionaTodosProdutos()
        {

            DataTable dt = new DataTable();
            try
            {
                bd = new AcessoBancodeDados();
                bd.Conectar();
                dt = bd.RetDataTable("SELECT cd_produto, ds_produto,vl_produto,qt_produto,qt_minima from tb_produto");

            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Selecionar todos os Produtos: " + ex.Message);
            }
            finally
            {
                bd = null;
            }

            return dt;
        }

        public void ExcluirProduto(string produto)
        {
            try
            {


                //Conecta no banco
                bd = new AcessoBancodeDados();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "DELETE FROM tb_produto where cd_produto = " + produto;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Excluir o produto: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void PesquisarProduto(string ds_produto)
        {
            try
            {
                //Conecta no banco
                bd = new AcessoBancodeDados();
                bd.Conectar();
                string comando = "SELECT tb_produto where ds_produto = " + ds_produto;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Pesquisar: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

    }
}
