﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_quarto_manutencao
    {
        private int id_quarto;
        private int id_manutencao;

        //get set (encupsulamento)

        public int Id_quarto { get => id_quarto; set => id_quarto = value; }
        public int Id_manutencao { get => id_manutencao; set => id_manutencao = value; }
    }
}
