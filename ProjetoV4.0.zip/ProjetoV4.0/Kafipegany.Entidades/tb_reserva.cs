﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_reserva
    {
        private int cd_reserva;
        private string dt_entrada;
        private string dt_saida;
        private string vl_valor;
        private string dt_dataReserva;
        private string id_funcionario;
        private string id_cliente;
        private string cd_status;

        // get set (encapsulamento)

        public int Cd_reserva { get => cd_reserva; set => cd_reserva = value; }
        public string Dt_entrada { get => dt_entrada; set => dt_entrada = value; }
        public string Dt_saida { get => dt_saida; set => dt_saida = value; }
        public string Vl_valor { get => vl_valor; set => vl_valor = value; }
        public string Dt_dataReserva { get => dt_dataReserva; set => dt_dataReserva = value; }
        public string Id_funcionario { get => id_funcionario; set => id_funcionario = value; }
        public string Id_cliente { get => id_cliente; set => id_cliente = value; }
        public string Cd_status { get => cd_status; set => cd_status = value; }
    }
}
