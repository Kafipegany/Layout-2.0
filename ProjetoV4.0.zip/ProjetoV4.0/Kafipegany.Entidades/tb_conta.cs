﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_conta
    {
        private int cd_conta;
        private string ds_conta;
        private string vl_diaria;
        private string vl_total;
        private string vl_desconto;
        private string vl_pago;
        private string ds_modoDePagamento;
        private string id_cliente;
        private string id_quarto;
        private string id_produto;

        // get set (emcapsulamento)

        public int Cd_conta { get => cd_conta; set => cd_conta = value; }
        public string Ds_conta { get => ds_conta; set => ds_conta = value; }
        public string Vl_diaria { get => vl_diaria; set => vl_diaria = value; }
        public string Vl_total { get => vl_total; set => vl_total = value; }
        public string Vl_desconto { get => vl_desconto; set => vl_desconto = value; }
        public string Vl_pago { get => vl_pago; set => vl_pago = value; }
        public string Ds_modoDePagamento { get => ds_modoDePagamento; set => ds_modoDePagamento = value; }
        public string Id_cliente { get => id_cliente; set => id_cliente = value; }
        public string Id_quarto { get => id_quarto; set => id_quarto = value; }
        public string Id_produto { get => id_produto; set => id_produto = value; }
    }
}
