﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_usuario
    {

        //Campos que atabela usuario possui 
        private int id;
        private string usuario;
        private string cargo;
        private string senha;

        //Parametro GET e SET
        public int Id { get => id; set => id = value; }
        public string Usuario { get => usuario; set => usuario = value; }
        public string Cargo { get => cargo; set => cargo = value; }
        public string Senha { get => senha; set => senha = value; }
    }
}
