﻿namespace KafipeganyV2._0
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenu));
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.btnIconeMinimizar = new System.Windows.Forms.PictureBox();
            this.btnIconeEncerrar = new System.Windows.Forms.PictureBox();
            this.btnSlide2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSlide3 = new System.Windows.Forms.PictureBox();
            this.btnSlide = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCadastros = new System.Windows.Forms.Button();
            this.pnlCadastros = new System.Windows.Forms.Panel();
            this.btnCadastroFornecedores = new System.Windows.Forms.Button();
            this.btnCadastrosQuartos = new System.Windows.Forms.Button();
            this.btnCadastrosHospedes = new System.Windows.Forms.Button();
            this.btnCadastroFuncionario = new System.Windows.Forms.Button();
            this.btnProdutos = new System.Windows.Forms.Button();
            this.pnlProduto = new System.Windows.Forms.Panel();
            this.btnProdutoEstoque = new System.Windows.Forms.Button();
            this.btnNewProduto = new System.Windows.Forms.Button();
            this.btnMovimentcao = new System.Windows.Forms.Button();
            this.pnlMovimentacao = new System.Windows.Forms.Panel();
            this.btnMovimentacaoGastos = new System.Windows.Forms.Button();
            this.btnMovimentacaoEntradaSaida = new System.Windows.Forms.Button();
            this.btnMovimentacaoNewServico = new System.Windows.Forms.Button();
            this.btnMovimentacaoNewVenda = new System.Windows.Forms.Button();
            this.btnReserva = new System.Windows.Forms.Button();
            this.pnlReserva = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.btnReservaNewReserva = new System.Windows.Forms.Button();
            this.btnChekInOut = new System.Windows.Forms.Button();
            this.pnlCheck = new System.Windows.Forms.Panel();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.btnCheckIn = new System.Windows.Forms.Button();
            this.btnRelatorios = new System.Windows.Forms.Button();
            this.pnlRelatorios = new System.Windows.Forms.Panel();
            this.btnRM = new System.Windows.Forms.Button();
            this.btnREs = new System.Windows.Forms.Button();
            this.btnRsvc = new System.Windows.Forms.Button();
            this.btnRVd = new System.Windows.Forms.Button();
            this.btnRPdt = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pnlTopo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeEncerrar)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSlide3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSlide)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlCadastros.SuspendLayout();
            this.pnlProduto.SuspendLayout();
            this.pnlMovimentacao.SuspendLayout();
            this.pnlReserva.SuspendLayout();
            this.pnlCheck.SuspendLayout();
            this.pnlRelatorios.SuspendLayout();
            this.pnlMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.Black;
            this.pnlTopo.Controls.Add(this.btnIconeMinimizar);
            this.pnlTopo.Controls.Add(this.btnIconeEncerrar);
            this.pnlTopo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopo.Location = new System.Drawing.Point(0, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(1386, 40);
            this.pnlTopo.TabIndex = 2;
            // 
            // btnIconeMinimizar
            // 
            this.btnIconeMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIconeMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIconeMinimizar.Image = ((System.Drawing.Image)(resources.GetObject("btnIconeMinimizar.Image")));
            this.btnIconeMinimizar.Location = new System.Drawing.Point(1300, 0);
            this.btnIconeMinimizar.Name = "btnIconeMinimizar";
            this.btnIconeMinimizar.Size = new System.Drawing.Size(40, 40);
            this.btnIconeMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnIconeMinimizar.TabIndex = 2;
            this.btnIconeMinimizar.TabStop = false;
            this.btnIconeMinimizar.Click += new System.EventHandler(this.btnIconeMinimizar_Click);
            // 
            // btnIconeEncerrar
            // 
            this.btnIconeEncerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIconeEncerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIconeEncerrar.Image = ((System.Drawing.Image)(resources.GetObject("btnIconeEncerrar.Image")));
            this.btnIconeEncerrar.Location = new System.Drawing.Point(1346, 0);
            this.btnIconeEncerrar.Name = "btnIconeEncerrar";
            this.btnIconeEncerrar.Size = new System.Drawing.Size(40, 40);
            this.btnIconeEncerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnIconeEncerrar.TabIndex = 1;
            this.btnIconeEncerrar.TabStop = false;
            this.btnIconeEncerrar.Click += new System.EventHandler(this.btnIconeEncerrar_Click);
            // 
            // btnSlide2
            // 
            this.btnSlide2.BackColor = System.Drawing.Color.White;
            this.btnSlide2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSlide2.Location = new System.Drawing.Point(250, 40);
            this.btnSlide2.Name = "btnSlide2";
            this.btnSlide2.Size = new System.Drawing.Size(1136, 748);
            this.btnSlide2.TabIndex = 5;
            this.btnSlide2.Paint += new System.Windows.Forms.PaintEventHandler(this.btnSlide2_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.btnSlide3);
            this.panel1.Controls.Add(this.btnSlide);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(233, 200);
            this.panel1.TabIndex = 2;
            // 
            // btnSlide3
            // 
            this.btnSlide3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSlide3.BackColor = System.Drawing.Color.Transparent;
            this.btnSlide3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSlide3.Image = ((System.Drawing.Image)(resources.GetObject("btnSlide3.Image")));
            this.btnSlide3.Location = new System.Drawing.Point(188, 0);
            this.btnSlide3.Name = "btnSlide3";
            this.btnSlide3.Size = new System.Drawing.Size(56, 32);
            this.btnSlide3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnSlide3.TabIndex = 4;
            this.btnSlide3.TabStop = false;
            this.btnSlide3.Visible = false;
            this.btnSlide3.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // btnSlide
            // 
            this.btnSlide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSlide.BackColor = System.Drawing.Color.Transparent;
            this.btnSlide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSlide.Image = ((System.Drawing.Image)(resources.GetObject("btnSlide.Image")));
            this.btnSlide.Location = new System.Drawing.Point(188, 0);
            this.btnSlide.Name = "btnSlide";
            this.btnSlide.Size = new System.Drawing.Size(56, 32);
            this.btnSlide.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnSlide.TabIndex = 3;
            this.btnSlide.TabStop = false;
            this.btnSlide.Click += new System.EventHandler(this.btnSlide_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 115);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // btnCadastros
            // 
            this.btnCadastros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(31)))));
            this.btnCadastros.BackgroundImage = global::KafipeganyV2._0.Properties.Resources.Cadastross;
            this.btnCadastros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastros.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCadastros.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnCadastros.FlatAppearance.BorderSize = 0;
            this.btnCadastros.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnCadastros.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.btnCadastros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastros.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastros.ForeColor = System.Drawing.Color.White;
            this.btnCadastros.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastros.Location = new System.Drawing.Point(0, 200);
            this.btnCadastros.Name = "btnCadastros";
            this.btnCadastros.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.btnCadastros.Size = new System.Drawing.Size(233, 50);
            this.btnCadastros.TabIndex = 2;
            this.btnCadastros.UseVisualStyleBackColor = false;
            this.btnCadastros.Click += new System.EventHandler(this.btnCadastros_Click);
            // 
            // pnlCadastros
            // 
            this.pnlCadastros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(68)))), ((int)(((byte)(71)))));
            this.pnlCadastros.Controls.Add(this.btnCadastroFornecedores);
            this.pnlCadastros.Controls.Add(this.btnCadastrosQuartos);
            this.pnlCadastros.Controls.Add(this.btnCadastrosHospedes);
            this.pnlCadastros.Controls.Add(this.btnCadastroFuncionario);
            this.pnlCadastros.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCadastros.Location = new System.Drawing.Point(0, 250);
            this.pnlCadastros.Name = "pnlCadastros";
            this.pnlCadastros.Size = new System.Drawing.Size(233, 139);
            this.pnlCadastros.TabIndex = 2;
            this.pnlCadastros.Visible = false;
            // 
            // btnCadastroFornecedores
            // 
            this.btnCadastroFornecedores.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastroFornecedores.FlatAppearance.BorderSize = 0;
            this.btnCadastroFornecedores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastroFornecedores.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastroFornecedores.ForeColor = System.Drawing.Color.White;
            this.btnCadastroFornecedores.Location = new System.Drawing.Point(81, 262);
            this.btnCadastroFornecedores.Name = "btnCadastroFornecedores";
            this.btnCadastroFornecedores.Size = new System.Drawing.Size(169, 40);
            this.btnCadastroFornecedores.TabIndex = 8;
            this.btnCadastroFornecedores.Text = "Fornecedores";
            this.btnCadastroFornecedores.UseVisualStyleBackColor = true;
            // 
            // btnCadastrosQuartos
            // 
            this.btnCadastrosQuartos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastrosQuartos.FlatAppearance.BorderSize = 0;
            this.btnCadastrosQuartos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrosQuartos.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrosQuartos.ForeColor = System.Drawing.Color.White;
            this.btnCadastrosQuartos.Location = new System.Drawing.Point(81, 92);
            this.btnCadastrosQuartos.Name = "btnCadastrosQuartos";
            this.btnCadastrosQuartos.Size = new System.Drawing.Size(169, 40);
            this.btnCadastrosQuartos.TabIndex = 4;
            this.btnCadastrosQuartos.Text = "Quartos";
            this.btnCadastrosQuartos.UseVisualStyleBackColor = true;
            this.btnCadastrosQuartos.Click += new System.EventHandler(this.btnCadastrosQuartos_Click);
            // 
            // btnCadastrosHospedes
            // 
            this.btnCadastrosHospedes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastrosHospedes.FlatAppearance.BorderSize = 0;
            this.btnCadastrosHospedes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrosHospedes.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrosHospedes.ForeColor = System.Drawing.Color.White;
            this.btnCadastrosHospedes.Location = new System.Drawing.Point(81, 46);
            this.btnCadastrosHospedes.Name = "btnCadastrosHospedes";
            this.btnCadastrosHospedes.Size = new System.Drawing.Size(169, 40);
            this.btnCadastrosHospedes.TabIndex = 3;
            this.btnCadastrosHospedes.Text = "Hóspedes";
            this.btnCadastrosHospedes.UseVisualStyleBackColor = true;
            this.btnCadastrosHospedes.Click += new System.EventHandler(this.btnCadastrosHospedes_Click);
            // 
            // btnCadastroFuncionario
            // 
            this.btnCadastroFuncionario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastroFuncionario.FlatAppearance.BorderSize = 0;
            this.btnCadastroFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastroFuncionario.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastroFuncionario.ForeColor = System.Drawing.Color.White;
            this.btnCadastroFuncionario.Location = new System.Drawing.Point(81, 0);
            this.btnCadastroFuncionario.Name = "btnCadastroFuncionario";
            this.btnCadastroFuncionario.Size = new System.Drawing.Size(169, 40);
            this.btnCadastroFuncionario.TabIndex = 2;
            this.btnCadastroFuncionario.Text = "Funcionáros";
            this.btnCadastroFuncionario.UseVisualStyleBackColor = true;
            this.btnCadastroFuncionario.Click += new System.EventHandler(this.btnCadastroFuncionario_Click);
            // 
            // btnProdutos
            // 
            this.btnProdutos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(31)))));
            this.btnProdutos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnProdutos.BackgroundImage")));
            this.btnProdutos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProdutos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProdutos.FlatAppearance.BorderSize = 0;
            this.btnProdutos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnProdutos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.btnProdutos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProdutos.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProdutos.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnProdutos.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnProdutos.Location = new System.Drawing.Point(0, 404);
            this.btnProdutos.Name = "btnProdutos";
            this.btnProdutos.Padding = new System.Windows.Forms.Padding(0, 20, 0, 0);
            this.btnProdutos.Size = new System.Drawing.Size(233, 50);
            this.btnProdutos.TabIndex = 3;
            this.btnProdutos.UseVisualStyleBackColor = false;
            this.btnProdutos.Click += new System.EventHandler(this.btnProdutos_Click);
            // 
            // pnlProduto
            // 
            this.pnlProduto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(68)))), ((int)(((byte)(71)))));
            this.pnlProduto.Controls.Add(this.btnProdutoEstoque);
            this.pnlProduto.Controls.Add(this.btnNewProduto);
            this.pnlProduto.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlProduto.Location = new System.Drawing.Point(0, 454);
            this.pnlProduto.Name = "pnlProduto";
            this.pnlProduto.Size = new System.Drawing.Size(233, 99);
            this.pnlProduto.TabIndex = 4;
            this.pnlProduto.Visible = false;
            // 
            // btnProdutoEstoque
            // 
            this.btnProdutoEstoque.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProdutoEstoque.FlatAppearance.BorderSize = 0;
            this.btnProdutoEstoque.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProdutoEstoque.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProdutoEstoque.ForeColor = System.Drawing.Color.White;
            this.btnProdutoEstoque.Location = new System.Drawing.Point(81, 46);
            this.btnProdutoEstoque.Name = "btnProdutoEstoque";
            this.btnProdutoEstoque.Size = new System.Drawing.Size(169, 40);
            this.btnProdutoEstoque.TabIndex = 3;
            this.btnProdutoEstoque.Text = "Estoque";
            this.btnProdutoEstoque.UseVisualStyleBackColor = true;
            this.btnProdutoEstoque.Click += new System.EventHandler(this.btnProdutoEstoque_Click);
            // 
            // btnNewProduto
            // 
            this.btnNewProduto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNewProduto.FlatAppearance.BorderSize = 0;
            this.btnNewProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewProduto.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewProduto.ForeColor = System.Drawing.Color.White;
            this.btnNewProduto.Location = new System.Drawing.Point(81, 0);
            this.btnNewProduto.Name = "btnNewProduto";
            this.btnNewProduto.Size = new System.Drawing.Size(169, 40);
            this.btnNewProduto.TabIndex = 2;
            this.btnNewProduto.Text = "Novo Produto";
            this.btnNewProduto.UseVisualStyleBackColor = true;
            this.btnNewProduto.Click += new System.EventHandler(this.btnNewProduto_Click);
            // 
            // btnMovimentcao
            // 
            this.btnMovimentcao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(31)))));
            this.btnMovimentcao.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMovimentcao.BackgroundImage")));
            this.btnMovimentcao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMovimentcao.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMovimentcao.FlatAppearance.BorderSize = 0;
            this.btnMovimentcao.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnMovimentcao.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.btnMovimentcao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMovimentcao.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovimentcao.ForeColor = System.Drawing.Color.White;
            this.btnMovimentcao.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnMovimentcao.Location = new System.Drawing.Point(0, 568);
            this.btnMovimentcao.Name = "btnMovimentcao";
            this.btnMovimentcao.Padding = new System.Windows.Forms.Padding(0, 8, 20, 0);
            this.btnMovimentcao.Size = new System.Drawing.Size(233, 50);
            this.btnMovimentcao.TabIndex = 7;
            this.btnMovimentcao.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMovimentcao.UseVisualStyleBackColor = false;
            // 
            // pnlMovimentacao
            // 
            this.pnlMovimentacao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(68)))), ((int)(((byte)(71)))));
            this.pnlMovimentacao.Controls.Add(this.btnMovimentacaoGastos);
            this.pnlMovimentacao.Controls.Add(this.btnMovimentacaoEntradaSaida);
            this.pnlMovimentacao.Controls.Add(this.btnMovimentacaoNewServico);
            this.pnlMovimentacao.Controls.Add(this.btnMovimentacaoNewVenda);
            this.pnlMovimentacao.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMovimentacao.Location = new System.Drawing.Point(0, 618);
            this.pnlMovimentacao.Name = "pnlMovimentacao";
            this.pnlMovimentacao.Size = new System.Drawing.Size(233, 182);
            this.pnlMovimentacao.TabIndex = 9;
            this.pnlMovimentacao.Visible = false;
            // 
            // btnMovimentacaoGastos
            // 
            this.btnMovimentacaoGastos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMovimentacaoGastos.FlatAppearance.BorderSize = 0;
            this.btnMovimentacaoGastos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMovimentacaoGastos.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovimentacaoGastos.ForeColor = System.Drawing.Color.White;
            this.btnMovimentacaoGastos.Location = new System.Drawing.Point(81, 138);
            this.btnMovimentacaoGastos.Name = "btnMovimentacaoGastos";
            this.btnMovimentacaoGastos.Size = new System.Drawing.Size(169, 40);
            this.btnMovimentacaoGastos.TabIndex = 5;
            this.btnMovimentacaoGastos.Text = "Gastos";
            this.btnMovimentacaoGastos.UseVisualStyleBackColor = true;
            // 
            // btnMovimentacaoEntradaSaida
            // 
            this.btnMovimentacaoEntradaSaida.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMovimentacaoEntradaSaida.FlatAppearance.BorderSize = 0;
            this.btnMovimentacaoEntradaSaida.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMovimentacaoEntradaSaida.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovimentacaoEntradaSaida.ForeColor = System.Drawing.Color.White;
            this.btnMovimentacaoEntradaSaida.Location = new System.Drawing.Point(81, 92);
            this.btnMovimentacaoEntradaSaida.Name = "btnMovimentacaoEntradaSaida";
            this.btnMovimentacaoEntradaSaida.Size = new System.Drawing.Size(169, 40);
            this.btnMovimentacaoEntradaSaida.TabIndex = 4;
            this.btnMovimentacaoEntradaSaida.Text = "Entrada e Sáida";
            this.btnMovimentacaoEntradaSaida.UseVisualStyleBackColor = true;
            // 
            // btnMovimentacaoNewServico
            // 
            this.btnMovimentacaoNewServico.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMovimentacaoNewServico.FlatAppearance.BorderSize = 0;
            this.btnMovimentacaoNewServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMovimentacaoNewServico.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovimentacaoNewServico.ForeColor = System.Drawing.Color.White;
            this.btnMovimentacaoNewServico.Location = new System.Drawing.Point(81, 46);
            this.btnMovimentacaoNewServico.Name = "btnMovimentacaoNewServico";
            this.btnMovimentacaoNewServico.Size = new System.Drawing.Size(169, 40);
            this.btnMovimentacaoNewServico.TabIndex = 3;
            this.btnMovimentacaoNewServico.Text = "Novo Serviço";
            this.btnMovimentacaoNewServico.UseVisualStyleBackColor = true;
            // 
            // btnMovimentacaoNewVenda
            // 
            this.btnMovimentacaoNewVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMovimentacaoNewVenda.FlatAppearance.BorderSize = 0;
            this.btnMovimentacaoNewVenda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMovimentacaoNewVenda.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovimentacaoNewVenda.ForeColor = System.Drawing.Color.White;
            this.btnMovimentacaoNewVenda.Location = new System.Drawing.Point(81, 0);
            this.btnMovimentacaoNewVenda.Name = "btnMovimentacaoNewVenda";
            this.btnMovimentacaoNewVenda.Size = new System.Drawing.Size(169, 40);
            this.btnMovimentacaoNewVenda.TabIndex = 2;
            this.btnMovimentacaoNewVenda.Text = "Nova Venda";
            this.btnMovimentacaoNewVenda.UseVisualStyleBackColor = true;
            // 
            // btnReserva
            // 
            this.btnReserva.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(31)))));
            this.btnReserva.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReserva.BackgroundImage")));
            this.btnReserva.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReserva.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReserva.FlatAppearance.BorderSize = 0;
            this.btnReserva.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnReserva.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.btnReserva.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReserva.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReserva.ForeColor = System.Drawing.Color.White;
            this.btnReserva.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnReserva.Location = new System.Drawing.Point(0, 815);
            this.btnReserva.Name = "btnReserva";
            this.btnReserva.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnReserva.Size = new System.Drawing.Size(233, 50);
            this.btnReserva.TabIndex = 9;
            this.btnReserva.UseVisualStyleBackColor = false;
            this.btnReserva.Click += new System.EventHandler(this.btnReserva_Click);
            // 
            // pnlReserva
            // 
            this.pnlReserva.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(68)))), ((int)(((byte)(71)))));
            this.pnlReserva.Controls.Add(this.button5);
            this.pnlReserva.Controls.Add(this.btnReservaNewReserva);
            this.pnlReserva.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlReserva.Location = new System.Drawing.Point(0, 865);
            this.pnlReserva.Name = "pnlReserva";
            this.pnlReserva.Size = new System.Drawing.Size(233, 103);
            this.pnlReserva.TabIndex = 10;
            this.pnlReserva.Visible = false;
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(81, 46);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(169, 40);
            this.button5.TabIndex = 3;
            this.button5.Text = "Consultar Reserva";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnReservaNewReserva
            // 
            this.btnReservaNewReserva.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReservaNewReserva.FlatAppearance.BorderSize = 0;
            this.btnReservaNewReserva.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReservaNewReserva.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReservaNewReserva.ForeColor = System.Drawing.Color.White;
            this.btnReservaNewReserva.Location = new System.Drawing.Point(81, 3);
            this.btnReservaNewReserva.Name = "btnReservaNewReserva";
            this.btnReservaNewReserva.Size = new System.Drawing.Size(169, 40);
            this.btnReservaNewReserva.TabIndex = 2;
            this.btnReservaNewReserva.Text = "Nova Reserva";
            this.btnReservaNewReserva.UseVisualStyleBackColor = true;
            this.btnReservaNewReserva.Click += new System.EventHandler(this.btnReservaNewReserva_Click);
            // 
            // btnChekInOut
            // 
            this.btnChekInOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(31)))));
            this.btnChekInOut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChekInOut.BackgroundImage")));
            this.btnChekInOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChekInOut.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnChekInOut.FlatAppearance.BorderSize = 0;
            this.btnChekInOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnChekInOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.btnChekInOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChekInOut.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChekInOut.ForeColor = System.Drawing.Color.White;
            this.btnChekInOut.Location = new System.Drawing.Point(0, 983);
            this.btnChekInOut.Name = "btnChekInOut";
            this.btnChekInOut.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnChekInOut.Size = new System.Drawing.Size(233, 50);
            this.btnChekInOut.TabIndex = 11;
            this.btnChekInOut.UseVisualStyleBackColor = false;
            this.btnChekInOut.Click += new System.EventHandler(this.btnChekInOut_Click);
            // 
            // pnlCheck
            // 
            this.pnlCheck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(68)))), ((int)(((byte)(71)))));
            this.pnlCheck.Controls.Add(this.btnCheckOut);
            this.pnlCheck.Controls.Add(this.btnCheckIn);
            this.pnlCheck.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCheck.Location = new System.Drawing.Point(0, 1033);
            this.pnlCheck.Name = "pnlCheck";
            this.pnlCheck.Size = new System.Drawing.Size(233, 102);
            this.pnlCheck.TabIndex = 12;
            this.pnlCheck.Visible = false;
            // 
            // btnCheckOut
            // 
            this.btnCheckOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCheckOut.FlatAppearance.BorderSize = 0;
            this.btnCheckOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheckOut.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckOut.ForeColor = System.Drawing.Color.White;
            this.btnCheckOut.Location = new System.Drawing.Point(81, 46);
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.Size = new System.Drawing.Size(169, 40);
            this.btnCheckOut.TabIndex = 3;
            this.btnCheckOut.Text = "Check Out";
            this.btnCheckOut.UseVisualStyleBackColor = true;
            this.btnCheckOut.Click += new System.EventHandler(this.btnCheckOut_Click);
            // 
            // btnCheckIn
            // 
            this.btnCheckIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCheckIn.FlatAppearance.BorderSize = 0;
            this.btnCheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheckIn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckIn.ForeColor = System.Drawing.Color.White;
            this.btnCheckIn.Location = new System.Drawing.Point(81, 3);
            this.btnCheckIn.Name = "btnCheckIn";
            this.btnCheckIn.Size = new System.Drawing.Size(169, 40);
            this.btnCheckIn.TabIndex = 2;
            this.btnCheckIn.Text = "Check In";
            this.btnCheckIn.UseVisualStyleBackColor = true;
            this.btnCheckIn.Click += new System.EventHandler(this.btnCheckIn_Click);
            // 
            // btnRelatorios
            // 
            this.btnRelatorios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(31)))));
            this.btnRelatorios.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRelatorios.BackgroundImage")));
            this.btnRelatorios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRelatorios.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRelatorios.FlatAppearance.BorderSize = 0;
            this.btnRelatorios.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnRelatorios.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.btnRelatorios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRelatorios.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRelatorios.ForeColor = System.Drawing.Color.White;
            this.btnRelatorios.Location = new System.Drawing.Point(0, 1150);
            this.btnRelatorios.Name = "btnRelatorios";
            this.btnRelatorios.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnRelatorios.Size = new System.Drawing.Size(233, 50);
            this.btnRelatorios.TabIndex = 13;
            this.btnRelatorios.UseVisualStyleBackColor = false;
            this.btnRelatorios.Click += new System.EventHandler(this.btnRelatorios_Click);
            // 
            // pnlRelatorios
            // 
            this.pnlRelatorios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(68)))), ((int)(((byte)(71)))));
            this.pnlRelatorios.Controls.Add(this.btnRM);
            this.pnlRelatorios.Controls.Add(this.btnREs);
            this.pnlRelatorios.Controls.Add(this.btnRsvc);
            this.pnlRelatorios.Controls.Add(this.btnRVd);
            this.pnlRelatorios.Controls.Add(this.btnRPdt);
            this.pnlRelatorios.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlRelatorios.Location = new System.Drawing.Point(0, 1200);
            this.pnlRelatorios.Name = "pnlRelatorios";
            this.pnlRelatorios.Size = new System.Drawing.Size(233, 234);
            this.pnlRelatorios.TabIndex = 14;
            this.pnlRelatorios.Visible = false;
            // 
            // btnRM
            // 
            this.btnRM.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRM.FlatAppearance.BorderSize = 0;
            this.btnRM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRM.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRM.ForeColor = System.Drawing.Color.White;
            this.btnRM.Location = new System.Drawing.Point(63, 184);
            this.btnRM.Name = "btnRM";
            this.btnRM.Size = new System.Drawing.Size(184, 40);
            this.btnRM.TabIndex = 6;
            this.btnRM.Text = "Relatório de Manutenção";
            this.btnRM.UseVisualStyleBackColor = true;
            this.btnRM.Click += new System.EventHandler(this.btnRM_Click);
            // 
            // btnREs
            // 
            this.btnREs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnREs.FlatAppearance.BorderSize = 0;
            this.btnREs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnREs.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnREs.ForeColor = System.Drawing.Color.White;
            this.btnREs.Location = new System.Drawing.Point(51, 138);
            this.btnREs.Name = "btnREs";
            this.btnREs.Size = new System.Drawing.Size(199, 40);
            this.btnREs.TabIndex = 5;
            this.btnREs.Text = "Relatórios de Entrada/Sáida";
            this.btnREs.UseVisualStyleBackColor = true;
            this.btnREs.Click += new System.EventHandler(this.btnREs_Click);
            // 
            // btnRsvc
            // 
            this.btnRsvc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRsvc.FlatAppearance.BorderSize = 0;
            this.btnRsvc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRsvc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRsvc.ForeColor = System.Drawing.Color.White;
            this.btnRsvc.Location = new System.Drawing.Point(66, 92);
            this.btnRsvc.Name = "btnRsvc";
            this.btnRsvc.Size = new System.Drawing.Size(184, 40);
            this.btnRsvc.TabIndex = 4;
            this.btnRsvc.Text = "Relatório de Serviços";
            this.btnRsvc.UseVisualStyleBackColor = true;
            this.btnRsvc.Click += new System.EventHandler(this.btnRsvc_Click);
            // 
            // btnRVd
            // 
            this.btnRVd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRVd.FlatAppearance.BorderSize = 0;
            this.btnRVd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRVd.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRVd.ForeColor = System.Drawing.Color.White;
            this.btnRVd.Location = new System.Drawing.Point(66, 46);
            this.btnRVd.Name = "btnRVd";
            this.btnRVd.Size = new System.Drawing.Size(184, 40);
            this.btnRVd.TabIndex = 3;
            this.btnRVd.Text = "Relatório de Vendas";
            this.btnRVd.UseVisualStyleBackColor = true;
            this.btnRVd.Click += new System.EventHandler(this.btnRVd_Click);
            // 
            // btnRPdt
            // 
            this.btnRPdt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRPdt.FlatAppearance.BorderSize = 0;
            this.btnRPdt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRPdt.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRPdt.ForeColor = System.Drawing.Color.White;
            this.btnRPdt.Location = new System.Drawing.Point(66, 0);
            this.btnRPdt.Name = "btnRPdt";
            this.btnRPdt.Size = new System.Drawing.Size(184, 40);
            this.btnRPdt.TabIndex = 2;
            this.btnRPdt.Text = "Relatório de Produtos";
            this.btnRPdt.UseVisualStyleBackColor = true;
            this.btnRPdt.Click += new System.EventHandler(this.btnRPdt_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(31)))));
            this.btnSair.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSair.BackgroundImage")));
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSair.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSair.FlatAppearance.BorderSize = 0;
            this.btnSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnSair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.White;
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSair.Location = new System.Drawing.Point(0, 1449);
            this.btnSair.Name = "btnSair";
            this.btnSair.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.btnSair.Size = new System.Drawing.Size(233, 50);
            this.btnSair.TabIndex = 15;
            this.btnSair.UseVisualStyleBackColor = false;
            // 
            // pnlMenu
            // 
            this.pnlMenu.AutoScroll = true;
            this.pnlMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.pnlMenu.Controls.Add(this.button9);
            this.pnlMenu.Controls.Add(this.btnSair);
            this.pnlMenu.Controls.Add(this.button8);
            this.pnlMenu.Controls.Add(this.pnlRelatorios);
            this.pnlMenu.Controls.Add(this.btnRelatorios);
            this.pnlMenu.Controls.Add(this.button7);
            this.pnlMenu.Controls.Add(this.pnlCheck);
            this.pnlMenu.Controls.Add(this.btnChekInOut);
            this.pnlMenu.Controls.Add(this.button6);
            this.pnlMenu.Controls.Add(this.pnlReserva);
            this.pnlMenu.Controls.Add(this.btnReserva);
            this.pnlMenu.Controls.Add(this.button4);
            this.pnlMenu.Controls.Add(this.pnlMovimentacao);
            this.pnlMenu.Controls.Add(this.btnMovimentcao);
            this.pnlMenu.Controls.Add(this.button3);
            this.pnlMenu.Controls.Add(this.pnlProduto);
            this.pnlMenu.Controls.Add(this.btnProdutos);
            this.pnlMenu.Controls.Add(this.button2);
            this.pnlMenu.Controls.Add(this.pnlCadastros);
            this.pnlMenu.Controls.Add(this.btnCadastros);
            this.pnlMenu.Controls.Add(this.panel1);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenu.Location = new System.Drawing.Point(0, 40);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(250, 748);
            this.pnlMenu.TabIndex = 3;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.Dock = System.Windows.Forms.DockStyle.Top;
            this.button9.Enabled = false;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(0, 1499);
            this.button9.Name = "button9";
            this.button9.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.button9.Size = new System.Drawing.Size(233, 15);
            this.button9.TabIndex = 22;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.button8.Enabled = false;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.Location = new System.Drawing.Point(0, 1434);
            this.button8.Name = "button8";
            this.button8.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.button8.Size = new System.Drawing.Size(233, 15);
            this.button8.TabIndex = 21;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.Enabled = false;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(0, 1135);
            this.button7.Name = "button7";
            this.button7.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.button7.Size = new System.Drawing.Size(233, 15);
            this.button7.TabIndex = 20;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.Enabled = false;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(0, 968);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.button6.Size = new System.Drawing.Size(233, 15);
            this.button6.TabIndex = 19;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.Enabled = false;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 800);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.button4.Size = new System.Drawing.Size(233, 15);
            this.button4.TabIndex = 18;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.Enabled = false;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(0, 553);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.button3.Size = new System.Drawing.Size(233, 15);
            this.button3.TabIndex = 17;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.Enabled = false;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(55)))), ((int)(((byte)(70)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 389);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.button2.Size = new System.Drawing.Size(233, 15);
            this.button2.TabIndex = 16;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1386, 788);
            this.Controls.Add(this.btnSlide2);
            this.Controls.Add(this.pnlMenu);
            this.Controls.Add(this.pnlTopo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMenu";
            this.Text = "frmMenu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlTopo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeEncerrar)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnSlide3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSlide)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlCadastros.ResumeLayout(false);
            this.pnlProduto.ResumeLayout(false);
            this.pnlMovimentacao.ResumeLayout(false);
            this.pnlReserva.ResumeLayout(false);
            this.pnlCheck.ResumeLayout(false);
            this.pnlRelatorios.ResumeLayout(false);
            this.pnlMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.PictureBox btnIconeMinimizar;
        private System.Windows.Forms.PictureBox btnIconeEncerrar;
        private System.Windows.Forms.Panel btnSlide2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox btnSlide3;
        private System.Windows.Forms.PictureBox btnSlide;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnCadastros;
        private System.Windows.Forms.Panel pnlCadastros;
        private System.Windows.Forms.Button btnCadastroFornecedores;
        private System.Windows.Forms.Button btnCadastrosQuartos;
        private System.Windows.Forms.Button btnCadastrosHospedes;
        private System.Windows.Forms.Button btnCadastroFuncionario;
        private System.Windows.Forms.Button btnProdutos;
        private System.Windows.Forms.Panel pnlProduto;
        private System.Windows.Forms.Button btnProdutoEstoque;
        private System.Windows.Forms.Button btnNewProduto;
        private System.Windows.Forms.Button btnMovimentcao;
        private System.Windows.Forms.Panel pnlMovimentacao;
        private System.Windows.Forms.Button btnMovimentacaoGastos;
        private System.Windows.Forms.Button btnMovimentacaoEntradaSaida;
        private System.Windows.Forms.Button btnMovimentacaoNewServico;
        private System.Windows.Forms.Button btnMovimentacaoNewVenda;
        private System.Windows.Forms.Button btnReserva;
        private System.Windows.Forms.Panel pnlReserva;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnReservaNewReserva;
        private System.Windows.Forms.Button btnChekInOut;
        private System.Windows.Forms.Panel pnlCheck;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.Button btnCheckIn;
        private System.Windows.Forms.Button btnRelatorios;
        private System.Windows.Forms.Panel pnlRelatorios;
        private System.Windows.Forms.Button btnRM;
        private System.Windows.Forms.Button btnREs;
        private System.Windows.Forms.Button btnRsvc;
        private System.Windows.Forms.Button btnRVd;
        private System.Windows.Forms.Button btnRPdt;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
    }
}