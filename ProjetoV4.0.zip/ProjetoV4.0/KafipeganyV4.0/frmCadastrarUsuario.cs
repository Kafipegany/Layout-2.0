﻿using Kafipegany.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafipegany.Entidades;


namespace KafipeganyV2._0.Formulários
{
    public partial class frmCadastrarUsuario : Form
    {
        UsuarioModel model = new UsuarioModel();
        tb_usuario tb = new tb_usuario();
        public frmCadastrarUsuario()
        {
            InitializeComponent();
        }

      
        //Botão de encerrar cadastro "X"
        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            
            Close();
            
            

        }



        private void frmCadastrarUsuario_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'kafipeganyDataSet.tb_usuario'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_usuarioTableAdapter.Fill(this.kafipeganyDataSet.tb_usuario);
            CarregarGrid();
        }
        private void CarregarGrid()
        {
            GridUsuario.DataSource = model.SelecionaTodosUsuarios();
        }
      


        //botões
        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
            HabilitarCampos();
            txtNome.Focus();
            btnSalvar.Enabled = true;
            
        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Desabilitar();
            tb.Usuario = txtNome.Text;
            tb.Cargo = txtCargo.Text;
            tb.Senha = txtSenha.Text;
            if (txtNome.Text == "" && txtCargo.Text == "" && txtSenha.Text == "" && txtConfSenha.Text == "")
            {
                MessageBox.Show("Preencha os campos e tente novamente!", "Erro ao Inserir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                HabilitarCampos();
            }
            else
            {
                if (txtNome.Text != "")
                {
                    if (txtCargo.Text != "")
                    {
                        if (txtSenha.Text != "")
                        {
                            if (txtConfSenha.Text != "")
                            {


                                if (txtCargo.Text == "Administrador" || txtCargo.Text == "Gerente" || txtCargo.Text == "Recepcionista")
                                {

                                    if (txtSenha.Text == txtConfSenha.Text)
                                    {

                                        if (txtID.Text == "")
                                        {
                                            model.Inserir(tb);
                                            MessageBox.Show("O Usuário foi Cadastrado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            LimparCampos();
                                        }
                                        else
                                        {
                                            tb.Id = int.Parse(txtID.Text);
                                            model.Atualizar(tb);
                                            MessageBox.Show("O Usuário foi Atualizado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            LimparCampos();
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("As senhas não conferen!", "Erro ao Inserir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        HabilitarCampos();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Selecione um Cargo e tente novamente!", "Erro ao Inserir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    HabilitarCampos();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Preencha o campo de Confirma Senha e tente novamente!", "Erro ao Inserir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                HabilitarCampos();
                                txtConfSenha.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Preencha o campo de Senha e tente novamente!", "Erro ao Inserir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            HabilitarCampos();
                            txtSenha.Focus();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Preencha o campo de Cargo e tente novamente!", "Erro ao Inserir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        HabilitarCampos();
                       
                    }
                }
                else
                {
                    MessageBox.Show("Preencha o campo de Nome e tente novamente!", "Erro ao Inserir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    HabilitarCampos();
                    txtNome.Focus();
                    return;
                }

            }

            CarregarGrid();

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Desabilitar();
            if (txtID.Text != "")
            {

                var result = MessageBox.Show("Deseja realmente excluir o registro selecionado?", "Eclusão Usuário!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    model.Excluir(txtID.Text);
                    MessageBox.Show("O Usuário foi Excluído com sucesso!", "Exclusão com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    CarregarGrid();
                }
            }
            else
            {
                MessageBox.Show("Selecione algum usuário e tente novamente!", "Erro ao excluir Usuario!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


  






        private void HabilitarCampos()
        {
            txtNome.Enabled = true;
            txtCargo.Enabled = true;
            txtSenha.Enabled = true;
            txtConfSenha.Enabled = true;
        }

        private void LimparCampos()
        {
            txtID.Text = "";
            txtNome.Text = "";
            txtCargo.Text = "";
            txtSenha.Text = "";
            txtConfSenha.Text = "";
        }

        private void Desabilitar()
        {
            txtNome.Enabled = false;
            txtCargo.Enabled = false;
            txtSenha.Enabled = false;
            txtConfSenha.Enabled = false;
        }

   

        private void GridUsuario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = GridUsuario.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNome.Text = GridUsuario.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtCargo.Text = GridUsuario.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtSenha.Text = GridUsuario.Rows[e.RowIndex].Cells[3].Value.ToString();
            HabilitarCampos();
        }
    }
}
