﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafipegany.Entidades;
using Kafipegany.Model;

namespace KafipeganyV2._0.Cadastros
{
    public partial class frmCadastroFuncionarios : Form
    {
        public frmCadastroFuncionarios()
        {
            InitializeComponent();
            

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {
            
                panel5.Location = new Point(this.Width / 2 - 575, this.Height / 2 - 396);
            


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frmCadastroFuncionarios_Load(object sender, EventArgs e)
        {

        }
    }
}